package com.example.actionbardemo;

import android.content.Intent;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActionBar ab=getSupportActionBar();
//        Toast.makeText(getApplicationContext(),"title",Toast.LENGTH_SHORT).show();
//      ab.hide();//To hide Action Bar
//        ab.setDisplayShowHomeEnabled(true);
//        ab.setDisplayUseLogoEnabled(true);
//
//        ab.setLogo(R.drawable.walletcopy);

//        ab.setTitle("RITApp");


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu)
    {
        MenuInflater inflater=getMenuInflater(); // This will give inflator
        inflater.inflate(R.menu.my_menu,menu);   // Attach the menu

        return super.onCreateOptionsMenu(menu); //Returns true or false

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item)
    {
        int itemID=item.getItemId();
        if (itemID==R.id.item1)
        {
//            Toast.makeText(getApplicationContext(),"Add Selected",Toast.LENGTH_SHORT).show();
            Intent i1=new Intent(this,add.class);
            startActivity(i1);
            return true;
        }
        else if (itemID==R.id.item2)
        {
            Toast.makeText(getApplicationContext(),"Delete Selected",Toast.LENGTH_SHORT).show();
            return true;
        }
        else if (itemID==R.id.item3)
        {

            finish();// just destroy current activity
            return  true;
//            System.exit(0); //Exit application completely
        }
        else
        {
            return super.onOptionsItemSelected(item);
        }


//         item.getTitle();
    }




}







