package edu.android.rit.activitylifecycle;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity
{

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.i("onCreate1","activity created");
    }
    protected void onStart()
    {
        super.onStart();
        Log.i("onStart1","activity started");
    }
    protected void onResume()
    {
        super.onResume();
        Log.i("onResume1","activity resumed");
    }
    protected void onPause()
    {
        super.onPause();
        Log.i("onPause1","activity paused");
    }
    protected void onDestroy()
    {
        super.onDestroy();
        Log.i("onDestroy1","activity destroyed");
    }
    protected void onStop()
    {
        super.onStop();
        Log.i("onStop1","activity stopped");
    }
    protected void onRestart()
    {
        super.onRestart();
        Log.i("onRestart1","activity restarted");
    }

    public void redirect(View v)
    {
        AlertDialog.Builder ab=new AlertDialog.Builder(this);
        ab.setIcon(R.mipmap.warning);
        ab.setTitle("Warning");
        ab.setMessage("Do you really want to go second activity.");
        ab.setPositiveButton("Yes", new DialogInterface.OnClickListener()
        {

                    @Override
                    public void onClick(DialogInterface dialog, int which)
                    {
                        Intent obj = new Intent(MainActivity.this, second.class);
                        startActivity(obj);
                        Toast.makeText(getApplicationContext(),"You are on another activity",Toast.LENGTH_LONG).show();
                    }
                });
        ab.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                Toast.makeText(getApplicationContext(),"You are one same activity",Toast.LENGTH_LONG).show();
            }
        });

        AlertDialog ad=ab.create();
        ad.show();

    }

    @Override
    public void onBackPressed()
    {
        AlertDialog.Builder ab=new AlertDialog.Builder(this);
        ab.setTitle("Warning");
        ab.setMessage("Dow you really want to quit?");
        ab.setCancelable(false);
        ab.setIcon(R.mipmap.warning);

        ab.setNegativeButton("No", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                dialog.cancel();
            }
        });

        ab.setPositiveButton("Yes", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which)
            {
                finish();
            }
        });
        AlertDialog ad=ab.create();
        ad.show();
    }
}
