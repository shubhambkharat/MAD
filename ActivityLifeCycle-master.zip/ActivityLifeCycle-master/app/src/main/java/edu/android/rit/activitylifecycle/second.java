package edu.android.rit.activitylifecycle;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;

public class second extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
        Log.i("onCreate2","activity created");
    }
    protected void onStart()
    {
        super.onStart();
        Log.i("onStart2","activity started");
    }
    protected void onResume()
    {
        super.onResume();
        Log.i("onResume2","activity resumed");
    }
    protected void onPause()
    {
        super.onPause();
        Log.i("onPause2","activity paused");
    }
    protected void onDestroy()
    {
        super.onDestroy();
        Log.i("onDestroy2","activity destroyed");
    }
    protected void onStop()
    {
        super.onStop();
        Log.i("onStop2","activity stopped");
    }
    protected void onRestart()
    {
        super.onRestart();
        Log.i("onRestart2","activity restarted");
    }
}
